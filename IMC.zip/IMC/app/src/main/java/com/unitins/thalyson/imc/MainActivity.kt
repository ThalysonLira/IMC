package com.unitins.thalyson.imc

import android.app.Activity
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var altura = findViewById<EditText>(R.id.txtAltura)
        var peso = findViewById<EditText>(R.id.txtPeso)

        var btCalcular = findViewById<Button>(R.id.btCalcular)
        var btCancelar = findViewById<Button>(R.id.btCancelar)

        var llvImc = findViewById<LinearLayout>(R.id.llvImc)
        var lbValorImc = findViewById<TextView>(R.id.valorImc)
        var lbInfo = findViewById<TextView>(R.id.infoPeso)
    }

    fun calcular(){

    }

    fun cancelar(){

    }

    fun exibir(){

    }
}