package com.thalysonlira.imc_java;

import android.app.Activity;
import android.graphics.Color;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {

    public EditText tfAltura, tfPeso;
    private Button btCancelar, btCalcular;
    public LinearLayout llvImc;
    public TextView lbValorImc, lbInfo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_main );

        tfAltura = findViewById( R.id.txtAltura);
        tfPeso = findViewById(R.id.txtPeso);

        btCalcular = findViewById(R.id.btCalcular);
        btCancelar = findViewById(R.id.btCancelar);

        llvImc = findViewById(R.id.llvImc);
        lbValorImc = findViewById(R.id.valorImc);
        lbInfo = findViewById(R.id.infoPeso);


    btCalcular.setOnClickListener( new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            try {
                double altura = Double.parseDouble(String.valueOf(tfAltura.getText()));
                double peso = Double.parseDouble(String.valueOf(tfPeso.getText()));

                double valor = peso / (altura * altura);

                exibir(valor);
            } catch (NullPointerException np){
                // Adicionar a mensagem de erro para o usuário (Os campos devem ser preenchidos)
                return;
            }
        }
    });

    btCancelar.setOnClickListener( new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            tfPeso.setText("");
            tfAltura.setText("");
            llvImc.setVisibility( View.INVISIBLE );
        }
    });
    }

    public void exibir(Double valor){
        llvImc.setVisibility( View.VISIBLE );
        lbValorImc.setText(valor.toString());   // Tentar exibir apenas duas casas decimais
        lbInfo.setText(situacao(valor));
    }

    private String situacao(Double valor){

        String classificacao, cor;

        if(valor < 16){
            classificacao = "Magreza Grave";
            cor = "#FF0000";
        }
        else if(valor > 16 && valor < 17){
            classificacao = "Magreza Moderada";
            cor = "#DF7401";
        }
        else if(valor > 16 && valor < 18.5){
            classificacao = "Magreza Leve";
            cor = "#A5DF00";
        }
        else if(valor > 18.5 && valor < 25){
            classificacao = "Saudável";
            cor = "#3ADF00";
        }
        else if(valor > 25 && valor < 30){
            classificacao = "Sobrepeso";
            cor = "#A5DF00";
        }
        else if(valor > 30 && valor < 35){
            classificacao = "Obesidade Grau I";
            cor = "#FFFF00";
        }
        else if(valor > 35 && valor < 40){
            classificacao = "Obesidade Grau II (Severa)";
            cor = "#DF7401";
        }
        else {
            classificacao = "Obesidade Grau III (Mórbida)";
            cor = "#FF0000";
        }

        lbValorImc.setBackgroundColor(Color.parseColor(cor));
        lbInfo.setBackgroundColor(Color.parseColor(cor));
        return classificacao;
    }
}
